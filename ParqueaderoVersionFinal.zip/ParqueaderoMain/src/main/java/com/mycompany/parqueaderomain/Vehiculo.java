/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */

import java.time.Duration;
import java.time.LocalDateTime;
      

public abstract class Vehiculo {

	private String placa;
	public String marca;
	public String modelo;
	public LocalDateTime horaEntrada;
        
        public Vehiculo(String placa, String marca, String modelo){
            this.placa = placa;
            this.marca = marca;
            this.modelo =modelo;
        }
        
        public void ingresar(LocalDateTime hora){
            this.horaEntrada = hora;
        }
        
        public double calcularCosto(Duration estancia) {
            double horas = estancia.toMinutes()/60.0;
            return tarifaHora() * horas;
        }

	public String getPlaca() {
		return this.placa;
	}

        public abstract double tarifaHora();
	/**
	 * 
	 * @param placa
	 */
	public void setPlaca(String placa) {
		this.placa = placa;
	}
        
}
