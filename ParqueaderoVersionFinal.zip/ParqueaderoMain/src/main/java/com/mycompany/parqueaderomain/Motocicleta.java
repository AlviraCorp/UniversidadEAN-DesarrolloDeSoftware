/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */
public class Motocicleta extends Vehiculo {

	public int cilindraje;
        
        public Motocicleta(String placa, String marca, String modelo, String tipoCombustible){
            super(placa, marca, modelo);
            this.cilindraje = cilindraje;
        }
        
	public double tarifaHora(){
            return 3000.0;
        }        


}
