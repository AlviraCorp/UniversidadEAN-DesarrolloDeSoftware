/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */
import java.time.LocalDateTime;



public class ParqueaderoMain {

    public static void main(String[] args) {
        Parqueadero parqueadero = new Parqueadero();
        
        Vehiculo automovil = new Automovil("NHL000", "Toyota", "Yaris", "Gasolina");
        Vehiculo camion = new Camion("HJW487", "Foton", "Npr", "20.0");
        Vehiculo motocicleta = new Motocicleta("EFY32", "BMW", "GS 750", "750");
        
        LocalDateTime horaActual = LocalDateTime.now();
        
        parqueadero.registrarEntrada(automovil, horaActual.minusMinutes(60));
        parqueadero.registrarEntrada(camion, horaActual.minusMinutes(101));
        parqueadero.registrarEntrada(motocicleta, horaActual.minusMinutes(125));
        
        
        System.out.println("\n");
        System.out.println("Costos de Parqueadero");
       
        System.out.println("Su vechiculo de placas NHL000 debe cancelar $" + parqueadero.registrarSalida("NHL000", horaActual));
        
        System.out.println("Su vechiculo de placas HJW487 debe cancelar $" + parqueadero.registrarSalida("HJW487", horaActual) );
        
        System.out.println("Su vechiculo de placas EFY32 debe cancelar $" + parqueadero.registrarSalida("EFY32", horaActual) );
        
    }
}
