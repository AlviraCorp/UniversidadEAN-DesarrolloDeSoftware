/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */
public class Automovil extends Vehiculo {

	public String tipoCombustible;
        
        public Automovil(String placa, String marca, String modelo, String tipoCombustible){
            super(placa, marca, modelo);
            this.tipoCombustible = tipoCombustible;
        }
        
	public double tarifaHora(){
            return 4000.0;
        }
}