/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;



public class Parqueadero {

	private List<Vehiculo> adentro = new ArrayList<>();

        public boolean registrarEntrada(Vehiculo v, LocalDateTime hora) {
            v.ingresar(hora);
            adentro.add(v);
            return true;
        }
        
        public double registrarSalida(String placa, LocalDateTime horaSalida){
            for(int i = 0; i < adentro.size(); i++){
                Vehiculo v = adentro.get(i);
                if (v.getPlaca().equals(placa)){
                    adentro.remove(i);
                    Duration estancia = Duration.between(v.horaEntrada, horaSalida);
                   return v.calcularCosto(estancia);
                }
            }
            return 0.0;
        }
        
        public List<Vehiculo> ListarAdentro(){
            return adentro;
        }


}
