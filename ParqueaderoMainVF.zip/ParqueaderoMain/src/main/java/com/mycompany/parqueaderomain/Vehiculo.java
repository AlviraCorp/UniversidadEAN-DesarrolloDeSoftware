/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */

import java.time.Duration;
import java.time.LocalDateTime;
      
// La clase abstract representa vehiculo en el sistema.
public abstract class Vehiculo {
        // Solo placa es privado, el resto es publico, consideramos que es el unico dato no generico aqui.
	private String placa; // Identificador del vehiculo dentro del parqueadero.
	public String marca; // La marca puede ser Toyota, Mazda, Honda, Foton, etc.
	public String modelo; // Los modelos puede ser Duke 390, NPR, GS 750, etc.
	public LocalDateTime horaEntrada; // Momento en el que la moto, camion o automovil ingresan.
        
        // contructor del vehiculo con placa, marca y modelo.
        
        public Vehiculo(String placa, String marca, String modelo){
            this.placa = placa;
            this.marca = marca;
            this.modelo =modelo;
        }
        
        // Registra hora de entrada
        public void ingresar(LocalDateTime hora){
            this.horaEntrada = hora;
        }
        
        // Calcula costo de parqueadero del vehiculo teniendo en cuenta su duracion en el mismo
        public double calcularCosto(Duration estancia) {
            double horas = estancia.toMinutes()/60.0;
            return tarifaHora() * horas;
        }

	public String getPlaca() {
		return this.placa;
	}
        
        // Jala la tarifa por hora, dependiendo de la subclase.
        public abstract double tarifaHora();
	/**
	 * 
	 * @param placa
	 */
	public void setPlaca(String placa) {
		this.placa = placa;
	}
        
}
