/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */

// Subclase de vehiculo
public class Motocicleta extends Vehiculo {

        // Atributo de cilindraje
	public int cilindraje;
        
        
        // Crea una motocicleta
        public Motocicleta(String placa, String marca, String modelo, String tipoCombustible){
            super(placa, marca, modelo);
            this.cilindraje = cilindraje;
        }
        
        // Establece tarifa para Motocicletas en $3.000
	public double tarifaHora(){
            return 3000.0;
        }        


}
