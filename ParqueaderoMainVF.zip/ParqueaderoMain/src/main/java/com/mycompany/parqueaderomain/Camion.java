/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */

// Subclase de vehiculo
public class Camion extends Vehiculo {
        // Atributo de tipo de capacidad de carga
	public double capacidadCarga;
        
        // Crea un camion.
        public Camion(String placa, String marca, String modelo, String tipoCombustible){
            super(placa, marca, modelo);
            this.capacidadCarga = capacidadCarga;
        }
        
        // Establece tarifa para Camion en $6.000        
	public double tarifaHora(){
            return 6000.0;
        }        

}
