/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parqueaderomain;

/**
 *
 * @author santi
 */

// Subclase de vehiculo
public class Automovil extends Vehiculo {

        // Atributo de tipo de combustible.
	public String tipoCombustible;
        
        // Crea un automovil
        public Automovil(String placa, String marca, String modelo, String tipoCombustible){
            super(placa, marca, modelo);
            this.tipoCombustible = tipoCombustible;
        }
        
        // Establece tarifa para automoviles en $4.000
	public double tarifaHora(){
            return 4000.0;
        }
}